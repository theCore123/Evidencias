const io = require('socket.io')(3000);
const dgram = require('dgram');
const server = dgram.createSocket('udp4'); 

io.on('connection', (socket) => {
  socket.on('message', (msg) => {
    console.log(`Mensaje recibido desde '${socket.id}': ${msg}`);
    socket.emit('message');
    server.send(msg, 41234, 'localhost', err => {
      if (err) throw err;
    });
  });
});