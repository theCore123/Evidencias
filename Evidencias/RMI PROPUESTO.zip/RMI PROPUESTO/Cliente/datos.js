const dgram = require('dgram');
const fs = require('fs');

const server = dgram.createSocket('udp4');
server.on('message', (msg) => {
  fs.appendFile('mensajes.txt', `${msg}\n`, err => {
    if (err) throw err;
    console.log('Mensaje guardado'); 
  });
});
server.bind(41234);