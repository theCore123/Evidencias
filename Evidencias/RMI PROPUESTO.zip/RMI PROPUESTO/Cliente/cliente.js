const io = require('socket.io-client');
const prompt = require('prompt-sync')();
const socket = io('http://localhost:3000'); 

function pedirMensaje() {
  let msg = prompt('Ingrese mensaje: ');
  socket.emit('message', msg);
  socket.on('message', () => {
    pedirMensaje();
  });
}
socket.on('connect', () => {
  pedirMensaje();
});