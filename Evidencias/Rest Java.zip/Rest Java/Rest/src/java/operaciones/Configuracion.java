
package operaciones;

import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("webresources")
public class Configuracion extends Application{

    
    
}
