
package operaciones;

import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Stateless
@Path("/operaciones")
public class Calculadora 
{
    @GET
    @Path("suma")
    public double Suma(@QueryParam("num1")double num1,@QueryParam("num2") double num2){
        return num1+num2;
    }
    
    
    @GET
    @Path("resta")
    public double resta(@QueryParam("num1")double num1,@QueryParam("num2") double num2)      
    {
        return num1-num2;
    }
    
    @GET
    @Path("factorial")
    public double factorial(@QueryParam("num3")double num3) {

        if (num3 >= 1) {
            return factorial(num3 - 1) * num3;
        }
        return 1;
    }
    
    @GET
    @Path("multiplicacion")
    public double multiplicacion(@QueryParam("num1")double num1,@QueryParam("num2") double num2)
    {
        return num1*num2;
    }
    
    @GET
    @Path("division")
    public double division(@QueryParam("num1")double num1,@QueryParam("num2")double num2)
    {
        return num1 / num2;
    }
    
    @GET
    @Path("potencia")
    public double potencia(@QueryParam("num1")double num1,@QueryParam("num2")double num2)
    {
        return Math.pow(num1, num2);
    }
    
    @GET
    @Path("modulo")
    public double modulo(@QueryParam("num1") double num1,@QueryParam("num2") double num2)
    {
        return num1%num2;
    }
    
    @GET
    @Path("raizCuadrada")
    public double raizCuadrada(@QueryParam("num3") double num3)        
    {
        return Math.sqrt(num3);
    }
    
    @GET
    @Path("logaritmo")
    public double logaritmo(@QueryParam("num3") double num3 )
    {
        return Math.log(num3);
    }
    
    @GET
    @Path("sin")
    public double sen(@QueryParam("num3") double num3){
        return Math.sin(num3);
    }
    
    @GET
    @Path("cos")
    public double cos(@QueryParam("num3") double num3){
        return Math.cos(num3);
    }
    
    @GET
    @Path("tan")
    public double tan(@QueryParam("num3") double num3){
        return Math.tan(num3);
    }
    
    @GET
    @Path("e")
    public double e(@QueryParam("num3") double num3){
        return Math.exp(num3);
    }
    
    @GET
    @Path("sinh")
    public double senh(@QueryParam("num3") double num3){
        return Math.sinh(num3);
    }
    
    @GET
    @Path("cosh")
    public double cosh(@QueryParam("num3") double num3){
        return Math.cos(num3);
    }
    
    @GET
    @Path("tanh")
    public double tanh(@QueryParam("num3") double num3){
        return Math.tanh(num3);
    }
}
